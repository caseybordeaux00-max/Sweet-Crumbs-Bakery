package com.sweetcrumbs.cakeshop

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.*
import android.view.*
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        setContentView(CakeShopView(this))
    }
}

private class CakeShopView(ctx: android.content.Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cream = Color.rgb(255,244,225)
    private val brown = Color.rgb(113,67,49)
    private val dark = Color.rgb(88,57,47)
    private val pink = Color.rgb(235,164,181)
    private val panel = Color.rgb(246,229,213)
    private var stage = 0
    private var baked = 0f
    private var assembled = false
    private var frosting = 0f
    private val berries = mutableListOf<PointF>()
    private val cuts = mutableListOf<Pair<PointF,PointF>>()
    private var down: PointF? = null
    private var money = 87.50

    init { text.typeface = Typeface.create("sans", Typeface.BOLD); setBackgroundColor(panel); isFocusable = true }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        p.style=Paint.Style.FILL; p.color=panel; c.drawRect(0f,0f,w,h,p)
        drawTop(c,w)
        when(stage){
            0 -> drawCustomer(c,w,h)
            1 -> drawBake(c,w,h)
            2 -> drawAssemble(c,w,h)
            3 -> drawFrost(c,w,h)
            4 -> drawDecorate(c,w,h)
            5 -> drawCut(c,w,h)
            6 -> drawServe(c,w,h)
            7 -> drawResult(c,w,h)
        }
    }

    private fun drawTop(c:Canvas,w:Float){
        p.color=Color.rgb(143,85,75);c.drawRect(0f,0f,w,58f,p)
        label(c,"DAY 3 · 12:15 PM",16f,36f,Color.WHITE,15f)
        label(c,"😊 100%",w-150f,36f,Color.WHITE,15f)
        label(c,"$"+String.format("%.2f",money),w-78f,36f,Color.WHITE,15f)
    }
    private fun drawCustomer(c:Canvas,w:Float,h:Float){
        p.color=Color.rgb(249,238,227);c.drawRect(0f,58f,w,h,p)
        label(c,"👩🏻",w*.14f,170f,Color.DKGRAY,58f)
        bubble(c, w*.27f,95f,w*.67f,210f,"Hi! I'd like a two-layer chocolate cake\nwith vanilla frosting, strawberries on top,\nand could you cut it into 8 slices please?")
        button(c,w/2,430f,250f,62f,"START ORDER")
        label(c,"Tap the counter to take the order",w/2-145f,530f,Color.DKGRAY,14f)
    }
    private fun drawBake(c:Canvas,w:Float,h:Float){
        title(c,"1. BAKE THE CAKE LAYERS")
        panelBox(c,20f,105f,w-20f,h-25f)
        drawPan(c, w*.26f,220f);drawPan(c,w*.65f,220f)
        p.color=Color.rgb(65,45,40);c.drawRoundRect(w*.38f,330f,w*.62f,455f,20f,20f,p)
        p.color=Color.rgb(239,164,113);c.drawRect(w*.42f,355f,w*.58f,440f,p)
        if(baked>=1){ drawLayer(c,w*.26f,220f); drawLayer(c,w*.65f,220f) }
        label(c,baked>=1f?"Layers baked! Tap a layer to continue.":"Tap the oven to bake both chocolate layers.",w/2-150f,h-55f,Color.DKGRAY,14f)
    }
    private fun drawAssemble(c:Canvas,w:Float,h:Float){
        title(c,"2. ASSEMBLE THE LAYERS")
        panelBox(c,20f,105f,w-20f,h-25f)
        drawCake(c,w/2,350f,false)
        label(c,"Drag the top layer onto the bottom layer",w/2-155f,h-55f,Color.DKGRAY,14f)
    }
    private fun drawFrost(c:Canvas,w:Float,h:Float){
        title(c,"3. ADD FROSTING")
        panelBox(c,20f,105f,w-20f,h-25f)
        drawCake(c,w/2,355f,true)
        label(c,"Swipe around the cake to spread the vanilla frosting",w/2-180f,h-55f,Color.DKGRAY,14f)
    }
    private fun drawDecorate(c:Canvas,w:Float,h:Float){
        title(c,"4. DECORATE")
        panelBox(c,20f,105f,w-20f,h-25f)
        drawCake(c,w/2,355f,true)
        for(b in berries){drawBerry(c,b.x,b.y)}
        label(c,"Drag strawberries from the tray onto the cake",w/2-160f,h-55f,Color.DKGRAY,14f)
    }
    private fun drawCut(c:Canvas,w:Float,h:Float){
        title(c,"5. CUT INTO 8 SLICES")
        panelBox(c,20f,105f,w-20f,h-25f)
        drawCake(c,w/2,355f,true)
        for((a,b) in cuts){p.color=Color.rgb(60,48,43);p.strokeWidth=4f;c.drawLine(a.x,a.y,b.x,b.y,p)}
        label(c,"Draw cuts across the cake — make 8 pieces",w/2-145f,h-55f,Color.DKGRAY,14f)
    }
    private fun drawServe(c:Canvas,w:Float,h:Float){
        title(c,"6. BOX AND SERVE")
        panelBox(c,20f,105f,w-20f,h-25f)
        p.color=Color.rgb(221,161,166);c.drawRoundRect(w*.20f,245f,w*.80f,455f,22f,22f,p)
        drawCake(c,w/2,330f,true)
        button(c,w/2,510f,230f,60f,"SERVE CAKE")
    }
    private fun drawResult(c:Canvas,w:Float,h:Float){
        title(c,"ORDER COMPLETE")
        panelBox(c,20f,105f,w-20f,h-25f)
        label(c,"⭐⭐⭐⭐⭐",w/2-90f,240f,Color.rgb(213,143,60),30f)
        bubble(c,w*.18f,275f,w*.82f,395f,"It's perfect! Exactly what I wanted!\nThank you so much!")
        label(c,"$18.00  +  $6.00 tip",w/2-100f,445f,Color.rgb(75,120,73),19f)
        button(c,w/2,520f,220f,58f,"NEXT CUSTOMER")
    }
    private fun drawPan(c:Canvas,x:Float,y:Float){p.color=Color.rgb(130,130,135);c.drawOval(x-70,y-35,x+70,y+35,p);p.color=Color.rgb(92,55,42);c.drawOval(x-55,y-22,x+55,y+22,p)}
    private fun drawLayer(c:Canvas,x:Float,y:Float){p.color=brown;c.drawRoundRect(x-65,y-20,x+65,y+35,15f,15f,p)}
    private fun drawCake(c:Canvas,x:Float,y:Float,iced:Boolean){
        p.color=brown;c.drawRoundRect(x-115,y+20,x+115,y+100,24f,24f,p);c.drawRoundRect(x-105,y-45,x+105,y+30,24f,24f,p)
        if(iced||frosting>0){p.color=cream;c.drawRoundRect(x-112,y+5,x+112,y+30,15f,15f,p);c.drawOval(x-105,y-57,x+105,y-22,p);c.drawRoundRect(x-105,y-38,x+105,y-8,15f,15f,p)}
        for(b in berries){if(stage<4)continue;drawBerry(c,b.x,b.y)}
    }
    private fun drawBerry(c:Canvas,x:Float,y:Float){p.color=Color.rgb(214,72,73);c.drawCircle(x,y,14f,p);p.color=Color.rgb(64,130,65);c.drawCircle(x,y-12,5f,p)}
    private fun title(c:Canvas,s:String){label(c,s,18f,90f,dark,16f)}
    private fun panelBox(c:Canvas,l:Float,t:Float,r:Float,b:Float){p.color=Color.rgb(231,198,177);c.drawRoundRect(l,t,r,b,22f,22f,p)}
    private fun bubble(c:Canvas,l:Float,t:Float,r:Float,b:Float,s:String){p.color=Color.rgb(255,250,244);c.drawRoundRect(l,t,r,b,20f,20f,p);val lines=s.split("\\n");for(i in lines.indices)label(c,lines[i],l+15,t+35+i*25,dark,15f)}
    private fun button(c:Canvas,x:Float,y:Float,w:Float,h:Float,s:String){p.color=Color.rgb(211,137,126);c.drawRoundRect(x-w/2,y-h/2,x+w/2,y+h/2,16f,16f,p);label(c,s,x-w/2+25,y+6,Color.WHITE,16f)}
    private fun label(c:Canvas,s:String,x:Float,y:Float,col:Int,size:Float){text.color=col;text.textSize=size;c.drawText(s,x,y,text)}

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x;val y=e.y
        if(e.action==MotionEvent.ACTION_DOWN){down=PointF(x,y);return true}
        if(e.action==MotionEvent.ACTION_UP){
            val d=down;down=null
            when(stage){
                0->{stage=1}
                1->{baked=1f;stage=2}
                2->{assembled=true;stage=3}
                3->{if(d!=null&&hypot(x-d.x,y-d.y)>35){frosting=1f;stage=4}}
                4->{if(d!=null){berries.add(PointF(x,y));if(berries.size>=3)stage=5}}
                5->{if(d!=null&&hypot(x-d.x,y-d.y)>45){cuts.add(Pair(d,PointF(x,y)));if(cuts.size>=3)stage=6}}
                6->{stage=7;money+=24.0}
                7->{stage=0; baked=0f;assembled=false;frosting=0f;berries.clear();cuts.clear()}
            }
            invalidate();return true
        }
        return true
    }
}
